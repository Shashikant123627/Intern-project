# Django management package init
